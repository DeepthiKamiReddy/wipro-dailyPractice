package com.example.day4;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

@Configuration
public class PersonRouter {

    @Bean
    public RouterFunction<ServerResponse> personRoutes(PersonHandler handler) {
        return RouterFunctions.route()
                .path("/persons", builder -> builder
                        .POST("", RequestPredicates.accept(MediaType.APPLICATION_JSON), handler::createPerson)
                        .GET("", handler::getAllPersons)
                        .GET("/{id}", handler::getPersonById)
                        .PUT("/{id}", RequestPredicates.accept(MediaType.APPLICATION_JSON), handler::updatePerson)
                        .DELETE("/{id}", handler::deletePerson)
                )
                .build();
    }
}

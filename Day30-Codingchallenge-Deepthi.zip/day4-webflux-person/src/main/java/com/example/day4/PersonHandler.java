package com.example.day4;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Validator;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Set;

@Component
public class PersonHandler {

    private final PersonRepository repository;
    private final Validator validator;

    public PersonHandler(PersonRepository repository, Validator validator) {
        this.repository = repository;
        this.validator = validator;
    }

    public Mono<ServerResponse> createPerson(ServerRequest request) {
        Mono<Person> personMono = request.bodyToMono(Person.class)
                .flatMap(this::validate);

        return personMono
                .flatMap(repository::save)
                .flatMap(saved -> ServerResponse
                        .created(URI.create("/persons/" + saved.getId()))
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(saved));
    }

    public Mono<ServerResponse> getPersonById(ServerRequest request) {
        String id = request.pathVariable("id");
        return repository.findById(id)
                .flatMap(person -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(person))
                .switchIfEmpty(ServerResponse.notFound().build());
    }

    public Mono<ServerResponse> getAllPersons(ServerRequest request) {
        Flux<Person> persons = repository.findAll();
        return ServerResponse.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(persons, Person.class);
    }

    public Mono<ServerResponse> updatePerson(ServerRequest request) {
        String id = request.pathVariable("id");

        Mono<Person> personMono = request.bodyToMono(Person.class)
                .flatMap(this::validate);

        return repository.findById(id)
                .flatMap(existing -> personMono
                        .flatMap(p -> repository.update(id, p))
                        .flatMap(updated -> ServerResponse.ok()
                                .contentType(MediaType.APPLICATION_JSON)
                                .bodyValue(updated)))
                .switchIfEmpty(ServerResponse.notFound().build());
    }

    public Mono<ServerResponse> deletePerson(ServerRequest request) {
        String id = request.pathVariable("id");
        return repository.deleteById(id)
                .then(ServerResponse.noContent().build());
    }

    private Mono<Person> validate(Person person) {
        Set<ConstraintViolation<Person>> violations = validator.validate(person);
        if (!violations.isEmpty()) {
            return Mono.error(new ConstraintViolationException(violations));
        }
        return Mono.just(person);
    }

    public Mono<ServerResponse> handleValidationError(ServerRequest request, Throwable error) {
        if (error instanceof ConstraintViolationException cve) {
            return ServerResponse.badRequest()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(cve.getMessage()));
        }
        return ServerResponse.status(500).bodyValue("Internal Server Error");
    }
}

package com.example.day4;

import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemoryPersonRepository implements PersonRepository {

    private final Map<String, Person> store = new ConcurrentHashMap<>();

    @Override
    public Mono<Person> save(Person person) {
        String id = person.getId();
        if (id == null || id.isBlank()) {
            id = UUID.randomUUID().toString();
            person.setId(id);
        }
        store.put(id, person);
        return Mono.just(person);
    }

    @Override
    public Mono<Person> findById(String id) {
        Person person = store.get(id);
        return person != null ? Mono.just(person) : Mono.empty();
    }

    @Override
    public Flux<Person> findAll() {
        return Flux.fromIterable(store.values());
    }

    @Override
    public Mono<Person> update(String id, Person person) {
        if (!store.containsKey(id)) {
            return Mono.empty();
        }
        person.setId(id);
        store.put(id, person);
        return Mono.just(person);
    }

    @Override
    public Mono<Void> deleteById(String id) {
        store.remove(id);
        return Mono.empty();
    }
}

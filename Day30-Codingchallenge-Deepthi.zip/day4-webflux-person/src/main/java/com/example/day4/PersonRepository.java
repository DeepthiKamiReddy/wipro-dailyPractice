package com.example.day4;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface PersonRepository {

    Mono<Person> save(Person person);

    Mono<Person> findById(String id);

    Flux<Person> findAll();

    Mono<Person> update(String id, Person person);

    Mono<Void> deleteById(String id);
}

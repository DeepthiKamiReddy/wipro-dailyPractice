package com.wipro.WiproSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(WiproSpringbootApplication.class, args);
	}

}

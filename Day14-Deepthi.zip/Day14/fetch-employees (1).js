// Fetch API example to get employees data
fetch("https://dummy.restapiexample.com/api/v1/employees")
  .then(response => response.json())
  .then(data => {
    console.log("Employees Data:");
    console.log(data);       // Display full response
    console.log(data.data);  // Display only employee list
  })
  .catch(error => console.error("Error fetching data:", error));
